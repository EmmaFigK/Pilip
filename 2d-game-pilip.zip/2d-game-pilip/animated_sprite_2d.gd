extends CharacterBody2D

@export var run_speed := 100.0
@export var acceleration := 320.0
@export var deceleration := 440.0
@export var jump_speed := 90.0
@export var gravity := 220.0

func _physics_process(delta: float) -> void:
	var direction := Input.get_axis("move_left", "move_right")
	var target_speed := direction * run_speed
	var rate := acceleration if direction != 0.0 else deceleration
	velocity.x = move_toward(velocity.x, target_speed, rate * delta)
	if not is_on_floor():
		velocity.y += gravity * delta
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = -jump_speed
	move_and_slide()
	if Input.is_action_just_pressed("move_right"):
		$Pilip.play("right")
	if Input.is_action_just_pressed("move_left"):
		$Pilip.play("left")
